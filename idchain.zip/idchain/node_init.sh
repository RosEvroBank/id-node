#!/bin/bash

geth --datadir "./" init genesis.json
