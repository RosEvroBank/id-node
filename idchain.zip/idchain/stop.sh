#!/bin/bash

pkill -f geth;
