#!/bin/bash

geth --datadir "./" account new
